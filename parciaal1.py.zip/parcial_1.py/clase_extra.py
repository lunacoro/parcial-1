cant_productos = 0

class Productos:
    def __init__(self, cant_productos:int):
        self.cant_productos = cant_productos
        
    def __str__(self) -> str:
        return (f'Productos: {self.cant_productos}')

def cantidad_productos():
    global cant_productos
    cant_productos += 1
    
    return cant_productos