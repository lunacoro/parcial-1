import os
import funciones_principales

def opcion(consigna: list, inventario1: list, inventario2: list):
    match funciones_principales.menu(consigna):
        case 1:
            funciones_principales.alta(inventario1, inventario2)
            opcion(consigna, inventario1, inventario2)
            
        case 2:
            funciones_principales.baja(inventario1, inventario2)
            opcion(consigna, inventario1, inventario2)
          
        case 3:
            funciones_principales.producto_modificar_compra(inventario1, inventario2)
            opcion(consigna, inventario1, inventario2)
            
        case 4:
            funciones_principales.listado_productos(inventario1, inventario2)
            opcion(consigna, inventario1, inventario2)
            

def main():
    inventario1 = []
    inventario2 = []
    consigna = ['------- MENU -------','[1] Alta', '[2] Baja', '[3] Modificacion', '[4] Listado', '\n[0] Salir']

    opcion(consigna, inventario1, inventario2)

    
main()