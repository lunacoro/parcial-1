class Producto:
    def __init__(self, codigo, detalle, peso, usd_compra):
        self.codigo = codigo
        self.detalle = detalle
        self.peso = peso
        self.usd_compra = usd_compra
    def __str__(self) -> str:
        return (f'Codigo: {self.codigo}\nDetalle: {self.detalle}\nPeso: {self.peso}\nUSD compra')