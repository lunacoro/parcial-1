import clase_producto
import clase_extra
import os 

def menu(lista_opciones: list):
    os.system('cls')

    for i in lista_opciones:
        print(i)
    valor = (input('Ingrese una opcion: '))
    while valor == False:
        valor = (input('Opcion inexistente, ingrese una opcion valida: '))
    
    valor = int(valor)
    
    while valor < 0 or valor > len(lista_opciones):
        valor = int(input('Opcion inexistente, ingrese una opcion valida: '))
    return valor 

def alta_producto():
    os.system('cls')
    codigo = input('Ingrese el codigo del producto. [X]Para volver al menu: ')
    
    if codigo == 'X' or codigo == 'x':
        return False

    detalle = input('Ingrese el detalle del producto: ')

    peso = input('Ingrese el peso del producto: ')
    usd_compra = input('Ingrese el precio de compra: ')
    
    input('Ingresado existosamente')
    
    
    return clase_producto.Producto(codigo, detalle, peso, usd_compra)

    
def productos():
    cantidad_productos = clase_extra.cant_productos

    return clase_extra.Productos(cantidad_productos)

def alta(inventario1: list, inventario2: list): #los agregue a mis listas
    if alta_producto() == False:
        return False

    inventario1.append(alta_producto())
    inventario2.append(productos())

#para mostrar mi lista
def listado_productos(inventario1: list, inventario2: list):
    
    os.system('cls')
    print('------ LISTADO DE PRODUCTOS ------')
    
    #con i me muestra lo que este cargado
    #con elemento me muestra la posicion
    
    for i in range(len(inventario1)):
        print(inventario1[i],inventario2[i])
    input('[ENTER]Volver: ') 
    

    


def busqueda_producto_baja(inventario1: list) -> int:
    codigo = input('Ingrese el codigo del producto a eliminar: ')

    for i in range(len(inventario1)):
        if inventario1[i].codigo == codigo:
            return i
    return None

def baja(inventario1: list, inventario2: list):
    os.system('cls')
    eliminar = busqueda_producto_baja(inventario1)
    if eliminar == None:
        print('El codigo no existe.')
        input('[ENTER] Para continuar...')
    
    if eliminar != None:
        del inventario1[eliminar]
        del inventario2[eliminar]

def busqueda_compra(inventario1: list):
    codigo_busqueda = input('Ingrese el codigo del producto que desea modificar: ')

    for i in range(len(inventario1)):
        if inventario1[i].codigo == codigo_busqueda:
            return i
    return None

def producto_modificar_compra(inventario1: list, inventario2: list): 
    os.system('cls')

    posicion = busqueda_compra(inventario1)
    
    if posicion == None:
        print('El codigo ingresado no existe.')
        input('[ENTER] Para continuar...')

    if posicion != None:
        match menu(['[1] USD COMPRA','USD VENTA']):
            case 1:
                nuevo_precio_compra = input('Ingrese el nuevo precio de compra: ')
                inventario1[posicion].usd_compra= nuevo_precio_compra